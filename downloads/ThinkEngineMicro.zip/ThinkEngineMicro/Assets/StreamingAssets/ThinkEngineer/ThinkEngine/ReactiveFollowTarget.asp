% ==========================================
% Segui il Target (no aritmetica inline)
% Direzioni discrete: -1, 0, 1
% ==========================================

% Direzione X
dX(1)  :- targetSensor_x(target,objectIndex(_),TX),
          agentSensor_x(agent,objectIndex(_),AX),
          TX > AX.
dX(-1) :- targetSensor_x(target,objectIndex(_),TX),
          agentSensor_x(agent,objectIndex(_),AX),
          TX < AX.
dX(0)  :- not dX(1), not dX(-1).

% Direzione Z
dZ(1)  :- targetSensor_z(target,objectIndex(_),TZ),
          agentSensor_z(agent,objectIndex(_),AZ),
          TZ > AZ.
dZ(-1) :- targetSensor_z(target,objectIndex(_),TZ),
          agentSensor_z(agent,objectIndex(_),AZ),
          TZ < AZ.
dZ(0)  :- not dZ(1), not dZ(-1).

% Y sempre 0
setOnActuator(agentActuator_desiredY(agent,objectIndex(I),0)) :-
    objectIndex(agentActuator, I).

% Applica X/Z con l'indice dinamico dell'attuatore
setOnActuator(agentActuator_desiredX(agent,objectIndex(I),DX)) :-
    objectIndex(agentActuator, I), dX(DX).
setOnActuator(agentActuator_desiredZ(agent,objectIndex(I),DZ)) :-
    objectIndex(agentActuator, I), dZ(DZ).
