% Forza movimento verso +X, ma compatibile con l'indice dinamico dell'attuatore
setOnActuator(agentActuator_desiredX(agent,objectIndex(I),1)) :- objectIndex(agentActuator, I).
setOnActuator(agentActuator_desiredY(agent,objectIndex(I),0)) :- objectIndex(agentActuator, I).
setOnActuator(agentActuator_desiredZ(agent,objectIndex(I),0)) :- objectIndex(agentActuator, I).
