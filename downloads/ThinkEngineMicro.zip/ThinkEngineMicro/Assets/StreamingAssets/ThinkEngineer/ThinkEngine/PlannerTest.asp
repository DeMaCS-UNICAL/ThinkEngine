% Piano minimale: ruota verso il target, poi fai un passo in avanti.

% Step 1: ruota verso il target
applyAction(1, "FaceTargetAction").
actionArgument(1, "agentName", "Agent").
actionArgument(1, "targetName", "Target").

% Step 2: fai un passo
applyAction(2, "StepForwardAction").
actionArgument(2, "agentName", "Agent").
actionArgument(2, "step", "1").  % stringa "1" (nel tuo Action fai Parse->float)
