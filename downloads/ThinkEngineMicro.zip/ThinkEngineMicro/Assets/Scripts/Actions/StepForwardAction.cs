using UnityEngine;
using System.Globalization;
using ThinkEngine.Planning;

public class StepForwardAction : ThinkEngine.Planning.Action
{
    public string agentName { get; set; }
    public string step     { get; set; } = "1"; // letto come string, convertito a float

    private Transform agent;
    private Vector3 startPos;
    private Vector3 targetPos;
    private bool initialized;

    private void ResolveRefs()
    {
        if (!agent && !string.IsNullOrEmpty(agentName))
        {
            var go = GameObject.Find(agentName);
            if (go) agent = go.transform;
        }
    }

    public override State Prerequisite()
    {
        ResolveRefs();
        return agent ? State.READY : State.ABORT;
    }

    public override void Do()
    {
        ResolveRefs();
        if (!agent) return;

        // inizializzazione una sola volta
        float stepF = 1f;
        float.TryParse(step, NumberStyles.Float, CultureInfo.InvariantCulture, out stepF);

        startPos  = agent.position;
        targetPos = startPos + agent.forward * stepF;
        initialized = true;
    }

    public override State Done()
    {
        if (!initialized || !agent) return State.READY;

        // avanza ogni frame finché non raggiunge il target
        agent.position = Vector3.MoveTowards(agent.position, targetPos, Time.deltaTime * 2f);

        float d = Vector3.Distance(agent.position, targetPos);
        return d < 0.01f ? State.READY : State.WAIT;
    }
}
