using UnityEngine;
using ThinkEngine.Planning;

public class FaceTargetAction : ThinkEngine.Planning.Action
{
    public string agentName { get; set; }
    public string targetName { get; set; }

    private Transform agent;
    private Transform target;
    private const float AngleThreshold = 5f;   // gradi
    private const float TurnStepRad = 0.2f;    // step per frame (in radianti)

    private void ResolveRefs()
    {
        if (!agent && !string.IsNullOrEmpty(agentName))
        {
            var go = GameObject.Find(agentName);
            if (go) agent = go.transform;
        }
        if (!target && !string.IsNullOrEmpty(targetName))
        {
            var go = GameObject.Find(targetName);
            if (go) target = go.transform;
        }
    }

    public override State Prerequisite()
    {
        ResolveRefs();
        if (!agent || !target) return State.ABORT;

        var to = target.position - agent.position;
        if (to.sqrMagnitude < 1e-6f) return State.SKIP; // stessa posizione: inutile ruotare
        return State.READY;
    }

    public override void Do()
    {
        // Intenzionalmente vuoto: il lavoro lo facciamo in Done() ogni frame
    }

    public override State Done()
    {
        ResolveRefs();
        if (!agent || !target) return State.READY;

        var to = target.position - agent.position;
        if (to.sqrMagnitude < 1e-9f) return State.READY;

        // ruota a piccoli passi finché non sotto la soglia
        var desired = Vector3.RotateTowards(agent.forward, to.normalized, TurnStepRad, 0f);
        agent.forward = desired;

        float angle = Vector3.Angle(agent.forward, to);
        return angle < AngleThreshold ? State.READY : State.WAIT;
    }
}
