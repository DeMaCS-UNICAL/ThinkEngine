using UnityEngine;

[RequireComponent(typeof(Transform))]
public class AgentMover : MonoBehaviour
{
    // Valori che ThinkEngine (o tu, a mano) imposterai
    public float desiredX;
    public float desiredY;
    public float desiredZ;

    [Header("Movement")]
    public float speed = 5f;            // aumenta per verificare il movimento
    public bool lockY = true;           // blocca l'asse Y se vuoi solo XZ

    [Header("Physics (opzionale)")]
    public bool useRigidbodyIfPresent = true;

    Rigidbody _rb;

    void Awake()
    {
        _rb = GetComponent<Rigidbody>();
        if (_rb && useRigidbodyIfPresent)
        {
            // Usando MovePosition serve che sia kinematic per evitare forze di fisica indesiderate
            _rb.isKinematic = true;
            _rb.useGravity = false; // opzionale
        }
    }

    void Update()
    {
        if (_rb && useRigidbodyIfPresent) return; // se usi Rigidbody, muovi in FixedUpdate
        MoveWithTransform(Time.deltaTime);
    }

    void FixedUpdate()
    {
        if (!(_rb && useRigidbodyIfPresent)) return;
        MoveWithRigidbody(Time.fixedDeltaTime);
    }

    void MoveWithTransform(float dt)
    {
        Vector3 dir = new Vector3(desiredX, desiredY, desiredZ);
        if (lockY) dir.y = 0f;

        if (dir.sqrMagnitude > 1e-6f) dir.Normalize();

        transform.position += dir * speed * dt;
    }

    void MoveWithRigidbody(float fdt)
    {
        Vector3 dir = new Vector3(desiredX, desiredY, desiredZ);
        if (lockY) dir.y = 0f;

        if (dir.sqrMagnitude > 1e-6f) dir.Normalize();

        Vector3 next = _rb.position + dir * speed * fdt;
        _rb.MovePosition(next);
    }
}
