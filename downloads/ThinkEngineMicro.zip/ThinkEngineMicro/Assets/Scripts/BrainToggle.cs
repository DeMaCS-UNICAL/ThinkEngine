using UnityEngine;
using TMPro;

public enum BrainMode { Reactive, Planner }

public class BrainToggle : MonoBehaviour
{
    [Header("Where to search for brains")]
    [Tooltip("Lascia vuoto per cercare in tutta la scena. Consigliato: assegna BrainHost qui.")]
    public Transform brainsRoot;

    [Header("Optional: disattiva l'Actuator in Planner mode")]
    public MonoBehaviour actuatorConfiguration; // ActuatorConfiguration dell'Agent (opzionale ma consigliato)

    [Header("Startup")]
    public BrainMode startMode = BrainMode.Reactive;

    [Header("Optional UI Label (TMP)")]
    public TMP_Text modeLabel;

    // trovati dinamicamente
    MonoBehaviour _reactiveBrain;
    MonoBehaviour _plannerBrain;

    BrainMode _mode;

    private void SetBrainEnabled(MonoBehaviour brain, bool on)
{
    if (!brain) return;

    // 1) Abilita/disabilita il componente MonoBehaviour
    brain.enabled = on;

    // 2) Prova a settare anche il flag "Enable Brain" interno (campo o propriet�)
    var t = brain.GetType();

    // campi possibili
    var field = t.GetField("EnableBrain") ?? t.GetField("enableBrain") ??
                t.GetField("Enable")      ?? t.GetField("enable");
    if (field != null && field.FieldType == typeof(bool))
    {
        field.SetValue(brain, on);
    }
    else
    {
        // propriet� possibili
        var prop = t.GetProperty("EnableBrain") ?? t.GetProperty("enableBrain") ??
                   t.GetProperty("Enable")      ?? t.GetProperty("enable");
        if (prop != null && prop.PropertyType == typeof(bool) && prop.CanWrite)
        {
            prop.SetValue(brain, on, null);
        }
    }
}


    void Awake()
    {
        // Trova i brain dinamicamente (priorit�: sotto brainsRoot; fallback: tutta la scena)
        if (brainsRoot)
        {
            foreach (var comp in brainsRoot.GetComponentsInChildren<MonoBehaviour>(true))
            {
                var n = comp.GetType().Name;
                if (_reactiveBrain == null && n.Contains("ReactiveBrain")) _reactiveBrain = comp;
                else if (_plannerBrain == null && n.Contains("PlannerBrain")) _plannerBrain = comp;
            }
        }
        if (_reactiveBrain == null || _plannerBrain == null)
        {
            foreach (var comp in Resources.FindObjectsOfTypeAll<MonoBehaviour>())
            {
                // ignora asset/prefab non in scena
                if (!comp || !comp.gameObject.scene.IsValid()) continue;
                var n = comp.GetType().Name;
                if (_reactiveBrain == null && n.Contains("ReactiveBrain")) _reactiveBrain = comp;
                else if (_plannerBrain == null && n.Contains("PlannerBrain")) _plannerBrain = comp;
                if (_reactiveBrain != null && _plannerBrain != null) break;
            }
        }
        if (_reactiveBrain == null) Debug.LogWarning("[BrainToggle] ReactiveBrain non trovato.");
        if (_plannerBrain == null)  Debug.LogWarning("[BrainToggle] PlannerBrain non trovato.");
    }

    void Start() => SetMode(startMode);

    // --- API per UI ---
    public void UseReactive() => SetMode(BrainMode.Reactive);
    public void UsePlanner()  => SetMode(BrainMode.Planner);
    public void ToggleMode()  => SetMode(_mode == BrainMode.Reactive ? BrainMode.Planner : BrainMode.Reactive);
    public void SetModeReactive(bool isReactive) => SetMode(isReactive ? BrainMode.Reactive : BrainMode.Planner);

    // --- Core ---
    public GameObject reactiveHost;
public GameObject plannerHost;

public void SetMode(BrainMode mode)
{
    _mode = mode;

    // Disattiva / Attiva host
    if (reactiveHost) reactiveHost.SetActive(mode == BrainMode.Reactive);
    if (plannerHost)  plannerHost.SetActive(mode == BrainMode.Planner);

    // Attiva solo il brain selezionato (se presenti)
    SetBrainEnabled(_reactiveBrain, mode == BrainMode.Reactive);
    SetBrainEnabled(_plannerBrain,  mode == BrainMode.Planner);

    // In Planner disattiva l�attuatore reattivo
    if (actuatorConfiguration) actuatorConfiguration.enabled = (mode == BrainMode.Reactive);

    UpdateLabel();
    Debug.Log($"[BrainToggle] Mode = {mode}");
}


    void UpdateLabel()
    {
        if (!modeLabel) return;
        modeLabel.text = _mode == BrainMode.Reactive ? "Mode: Reactive" : "Mode: Planner";
    }
}
