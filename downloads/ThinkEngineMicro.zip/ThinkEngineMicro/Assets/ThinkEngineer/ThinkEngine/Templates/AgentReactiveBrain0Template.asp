%For runtime instantiated GameObject, only the prefab mapping is provided. Use that one substituting the gameobject name accordingly.
 %Sensors.
%targetSensor_y(target,objectIndex(Index),Value).
%targetSensor_x(target,objectIndex(Index),Value).
%targetSensor_z(target,objectIndex(Index),Value).
%agentSensor_x(agent,objectIndex(Index),Value).
%agentSensor_y(agent,objectIndex(Index),Value).
%agentSensor_z(agent,objectIndex(Index),Value).
%Actuators:
setOnActuator(agentActuator_desiredX(agent,objectIndex(Index),Value)) :-objectIndex(agentActuator, Index), .
setOnActuator(agentActuator_desiredY(agent,objectIndex(Index),Value)) :-objectIndex(agentActuator, Index), .
setOnActuator(agentActuator_desiredZ(agent,objectIndex(Index),Value)) :-objectIndex(agentActuator, Index), .
