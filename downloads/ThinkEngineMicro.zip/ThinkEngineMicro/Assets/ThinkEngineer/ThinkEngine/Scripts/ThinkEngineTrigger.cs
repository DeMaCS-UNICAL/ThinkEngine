using UnityEngine;

namespace ThinkEngine
{
    // Stesso namespace della libreria
    public class ThinkEngineTrigger : ScriptableObject
    {
        public static bool AlwaysTrue() {
      if (Time.frameCount % 30 == 0) Debug.Log("[ThinkTrigger] AlwaysTrue");
      return true;
    }
        public static bool Every10Frames() => Time.frameCount % 10 == 0;
    }
}
